package datastructures;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DataStructures {

    public static void main(String[] args) {

        String filelocation = "C:\\Users\\ALWAFER\\Desktop\\vvv.txt";
        String searchitem = "e10ed94a1ce505fe0de3d4a628f96f70945b3e78f87c7f8e3bf55a10240a9900";

        try {

            List<String> textsList = readLines(filelocation);
            String[] sortedTexts = textsList.toArray(new String[0]);
            Arrays.sort(sortedTexts);
            // ترمي خطاء عند ادخال موقع الملف خطاء
            searchAndPrintResults(sortedTexts, searchitem);

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

    }

    //دالة قراءة الهاش من الملف النصي
    private static List<String> readLines(String filelocation) throws IOException {
        List<String> liness = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filelocation))) {
            String line;
            while ((line = br.readLine()) != null) {
                liness.add(line);
            }
        }
        return liness;
    }

    //دالة اختبار البحث
    private static void searchAndPrintResults(String[] texts, String searchitem) {
        int linearSteps = linearSearch(texts, searchitem);

        if (linearSteps > 8) {
            int binarySteps = binarySearch(texts, searchitem);
            if (binarySteps > 15) {
                int ternarySteps = ternarySearch(texts, searchitem);
                if (ternarySteps != -1) {
                    System.out.println("The text has been found" + "||" + ternarySteps + "||" + " Step using ternary search.");
                } else {
                    System.out.println("The text is not in the list.");
                }
            } else {
                if (binarySteps != -1) {
                    System.out.println("The text has been found" + "||" + binarySteps + "||" + " Step using binary search.");
                } else {
                    System.out.println("The text is not in the list.");
                }
            }
        } else {
            if (linearSteps != -1) {
                System.out.println("The text has been found" + "||" + linearSteps + "||" + " Step using linear search.");
            } else {
                System.out.println("The text is not in the list.");
            }
        }
    }

    // دالة البحث الخطي
    private static int linearSearch(String[] texts, String target) {
        int steps = 0;
        for (String text : texts) {
            steps++;
            if (text.equals(target)) {
                return steps;
            }
        }
        return -1;
    }

    // دالة بحث الثنائي
    private static int binarySearch(String[] texts, String target) {
        int left = 0;
        int right = texts.length - 1;
        int steps = 0;

        while (left <= right) {
            steps++;
            int mid = left + (right - left) / 2;
            int cmp = texts[mid].compareTo(target);

            if (cmp < 0) {
                left = mid + 1;
            } else if (cmp > 0) {
                right = mid - 1;
            } else {
                return steps;
            }
        }
        return -1;
    }

    // دالة البحث الثلاثي
    private static int ternarySearch(String[] texts, String target) {
        int left = 0;
        int right = texts.length - 1;
        int steps = 0;

        while (left <= right) {
            steps++;
            int m1 = left + (right - left) / 3;
            int m2 = right - (right - left) / 3;

            int c1 = texts[m1].compareTo(target);
            int c2 = texts[m2].compareTo(target);

            if (c1 == 0) {
                return steps;
            }
            if (c2 == 0) {
                return steps;
            }
            if (c1 > 0) {
                right = m1 - 1;
            } else if (c2 < 0) {
                left = m2 + 1;
            } else {
                left = m1 + 1;
                right = m2 - 1;
            }
        }
        return -1;
    }
}
